import json
import boto3

def lambda_handler(event, context):
    # Initialize an empty list to store bucket names
    bucket_names = []
    
    try:
        # Create an S3 client
        s3_client = boto3.client('s3')
        
        # Call list_buckets() to retrieve information about all S3 buckets
        response = s3_client.list_buckets()
        
        # Extract bucket names from the response
        for bucket in response['Buckets']:
            bucket_names.append(bucket['Name'])
        
        # Return the bucket names in the response
        return {
            'statusCode': 200,
            'body': json.dumps(bucket_names)
        }
    
    except Exception as e:
        # If an error occurs, return an error response
        return {
            'statusCode': 500,
            'body': json.dumps(str(e))
        }
